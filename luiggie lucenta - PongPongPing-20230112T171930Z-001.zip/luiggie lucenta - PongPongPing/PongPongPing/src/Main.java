
public class Main {


    public static void main(String[] args) {

        new Menu();
        
        playMusic();

    }

	private static void playMusic() {
		// TODO Auto-generated method stub
		
	}
    
}
